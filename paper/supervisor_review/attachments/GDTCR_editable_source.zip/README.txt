Compile manuscript.tex and supplementary.tex twice with pdflatex from paper/supervisor_review/. The two optional note sources compile there too. Relative figure paths are preserved.
