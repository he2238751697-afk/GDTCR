import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
index=json.loads((root/'SNAPSHOT_INDEX.json').read_text())
for name,record in index.items():
    out=root/'restored_snapshots'/name
    out.mkdir(parents=True,exist_ok=True)
    for relative,h in record['files_sha256'].items():
        path=Path(relative)
        assert not path.is_absolute() and '..' not in path.parts
        src=root/'source_objects'/h
        assert hashlib.sha256(src.read_bytes()).hexdigest()==h
        dst=out/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    shutil.copyfile(root/'frozen_manifests'/(name+'.json'),out/'snapshot.json')
print('Restored',len(index),'exact source snapshots; port execution manifest paths separately.')
